export.model = function(){
	return new mongoose.Schema({
		name:String
		, location:String
		, route:String
	});
}


