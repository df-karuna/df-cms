var mongoose = require('mongoose');
var Schema = mongoose.Schema;


var UserScm = mongoose.model('Plugins', new Schema({
							id:String
							,password:String
							,name:String
							,gisu:Number
							,email:String
							,address:String
							,reception:Boolean
						}));

export.findAll = function(cb){
	
	UserScm.find()
					.exec(cb);
}
exports.addUser = function(userInfo){
	var user = new UserScm(userInfo);
	user.save(function(err){
		if(err) return handleError(err);
	}
}
