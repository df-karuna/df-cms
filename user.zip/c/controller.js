/*
 * GET controltower default route

exports.list = function(req, res){
  res.send("respond with a resource");
};
exports.index = function(req, res){
  res.render('index', { title: 'Express' });
};
*/
var fs = require('fs')
  , formidable = require('formidable');

var pluginInfo = JSON.parse( fs.readFileSync('./plugins/controlTower/info.json', 'utf8') );


var name = pluginInfo['name']
	//, view = pluginInfo['directory']+"/v";
	, view = pluginInfo['directory']+"/"+ (pluginInfo['view']||"v")
	, verbs = pluginInfo['verbs'];

exports.addUserForm = function(app){
	app.get(verbs.addUserForm.route, function(req, res){
		var data = {};

		data.submitVal = '가입하기';
		data.action = 'addUser';
		data.currNum = new Date().getFullYear()-1988 +1;

		res.render(view+'/userForm', data);
		console.log(view+'/userForm');
	}
}
exports.addUser = function(app){
	app.post(verbs.addUser.route, function(req, res){
		res.end(req);
		console.log('addUser');
	}
}
exports.modUserForm = function(app){
	app.get(verbs.index.route, function(req, res){
		var data = {};

		data.submitVal = '수정완료';
		data.action = 'modUser';
		data.currNum = new Date().getFullYear()-1988 +1;

		res.render(view+'/userForm');
		console.log(view+'/userForm');
	}
}
exports.modUser = function(app){
	app.post(verbs.index.route, function(req, res){
		console.log('modUser');
	}
}
